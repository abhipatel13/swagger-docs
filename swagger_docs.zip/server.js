const express = require('express');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
const { createProxyMiddleware } = require('http-proxy-middleware');
const cors = require('cors');

const app = express();
const swaggerDocument = YAML.load('./apidocs.yaml');

// Enable CORS for all requests
app.use(cors());

// Serve Swagger documentation
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Performance Testing Endpoints
app.get('/api/performance-testing/performance/small-query', (req, res) => {
  // Echo back the query parameters for small query test
  res.json({
    args: req.query,
    headers: req.headers,
    url: `${req.protocol}://${req.get('host')}${req.originalUrl}`
  });
});

app.get('/api/performance-testing/performance/large-query', (req, res) => {
  // Echo back the query parameters for large query test
  res.json({
    args: req.query,
    headers: req.headers,
    url: `${req.protocol}://${req.get('host')}${req.originalUrl}`
  });
});

app.get('/api/performance-testing/performance/load-test', (req, res) => {
  const { paramCount = 10, paramSize = 10, delay = 0 } = req.query;
  
  // Generate test parameters based on configuration
  const testParams = {};
  for (let i = 1; i <= Math.min(parseInt(paramCount), 1000); i++) {
    testParams[`param${i}`] = 'x'.repeat(Math.min(parseInt(paramSize), 1000));
  }
  
  // Apply artificial delay if specified
  setTimeout(() => {
    res.json({
      testConfig: {
        paramCount: parseInt(paramCount),
        paramSize: parseInt(paramSize),
        delay: parseInt(delay)
      },
      performance: {
        responseTime: Date.now() - req.startTime,
        urlLength: req.originalUrl.length,
        paramCount: Object.keys(testParams).length
      },
      args: testParams,
      headers: req.headers,
      url: `${req.protocol}://${req.get('host')}${req.originalUrl}`
    });
  }, parseInt(delay));
});

// Add timing middleware for performance testing
app.use('/api/performance-testing', (req, res, next) => {
  req.startTime = Date.now();
  next();
});

// Regression Testing Endpoints
app.get('/api/regression-testing/regression/status-code', (req, res) => {
  const { testType = 'success' } = req.query;
  
  switch (testType) {
    case 'error':
      return res.status(400).json({
        status: '400 Bad Request',
        message: 'Status code verification - error test',
        timestamp: new Date().toISOString(),
        testType: 'error'
      });
    case 'notfound':
      return res.status(404).json({
        status: '404 Not Found',
        message: 'Status code verification - not found test',
        timestamp: new Date().toISOString(),
        testType: 'notfound'
      });
    case 'unauthorized':
      return res.status(401).json({
        status: '401 Unauthorized',
        message: 'Status code verification - unauthorized test',
        timestamp: new Date().toISOString(),
        testType: 'unauthorized'
      });
    default:
      return res.status(200).json({
        status: '200 OK',
        message: 'Status code verification successful',
        timestamp: new Date().toISOString(),
        testType: 'success'
      });
  }
});

app.post('/api/regression-testing/regression/json-schema', (req, res) => {
  try {
    const books = req.body;
    
    // Validate that the request body is an array of books
    if (!Array.isArray(books)) {
      return res.status(400).json({
        validation: {
          isValid: false,
          errors: ['Request body must be an array of books'],
          timestamp: new Date().toISOString()
        }
      });
    }
    
    // Validate each book has required properties
    const errors = [];
    books.forEach((book, index) => {
      if (!book.title || typeof book.title !== 'string') {
        errors.push(`Book ${index + 1}: missing or invalid title`);
      }
      if (!book.author || typeof book.author !== 'string') {
        errors.push(`Book ${index + 1}: missing or invalid author`);
      }
      if (!book.published || typeof book.published !== 'number') {
        errors.push(`Book ${index + 1}: missing or invalid published year`);
      }
    });
    
    if (errors.length > 0) {
      return res.status(400).json({
        validation: {
          isValid: false,
          errors: errors,
          timestamp: new Date().toISOString()
        }
      });
    }
    
    res.json({
      data: books,
      validation: {
        isValid: true,
        errors: [],
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    res.status(500).json({
      validation: {
        isValid: false,
        errors: ['Internal server error during schema validation'],
        timestamp: new Date().toISOString()
      }
    });
  }
});

app.post('/api/regression-testing/regression/response-body', (req, res) => {
  try {
    const book = req.body;
    
    // Validate required properties
    if (!book.title || typeof book.title !== 'string') {
      return res.status(400).json({
        verification: {
          structureValid: false,
          contentValid: false,
          typeValid: false,
          timestamp: new Date().toISOString()
        }
      });
    }
    
    if (!book.author || typeof book.author !== 'string') {
      return res.status(400).json({
        verification: {
          structureValid: false,
          contentValid: false,
          typeValid: false,
          timestamp: new Date().toISOString()
        }
      });
    }
    
    if (!book.published || typeof book.published !== 'number') {
      return res.status(400).json({
        verification: {
          structureValid: false,
          contentValid: false,
          typeValid: false,
          timestamp: new Date().toISOString()
        }
      });
    }
    
    // Check specific content for "Sapiens" book
    const isSapiensBook = book.title === 'Sapiens' && 
                         book.author === 'Yuval Noah Harari' && 
                         book.published === 2011;
    
    res.json({
      data: book,
      verification: {
        structureValid: true,
        contentValid: isSapiensBook,
        typeValid: true,
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    res.status(500).json({
      verification: {
        structureValid: false,
        contentValid: false,
        typeValid: false,
        timestamp: new Date().toISOString()
      }
    });
  }
});

app.get('/api/regression-testing/regression/response-time', (req, res) => {
  const timeout = parseInt(req.query.timeout) || 5000;
  const iterations = parseInt(req.query.iterations) || 1;
  const startTime = Date.now();
  
  // Simulate some processing time
  setTimeout(() => {
    const responseTime = Date.now() - startTime;
    const isWithinThreshold = responseTime < timeout;
    
    if (!isWithinThreshold) {
      return res.status(408).json({
        performance: {
          responseTime: responseTime,
          threshold: timeout,
          isWithinThreshold: false,
          iterations: iterations,
          averageResponseTime: responseTime
        },
        timestamp: new Date().toISOString()
      });
    }
    
    res.json({
      performance: {
        responseTime: responseTime,
        threshold: timeout,
        isWithinThreshold: true,
        iterations: iterations,
        averageResponseTime: responseTime
      },
      timestamp: new Date().toISOString()
    });
  }, Math.random() * 1000); // Random delay up to 1 second
});

app.get('/api/regression-testing/regression/headers', (req, res) => {
  const validateContentType = req.query.validateContentType !== 'false';
  const validateSecurity = req.query.validateSecurity !== 'false';
  
  // Set appropriate headers
  res.set({
    'Content-Type': 'application/json',
    'Content-Length': JSON.stringify({}).length.toString(),
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  
  const headers = res.getHeaders();
  
  res.json({
    headers: headers,
    verification: {
      contentTypeValid: validateContentType ? headers['content-type']?.includes('application/json') : true,
      contentLengthPresent: headers['content-length'] !== undefined,
      securityHeadersValid: validateSecurity ? 
        (headers['x-content-type-options'] && headers['x-frame-options']) : true,
      corsHeadersValid: headers['access-control-allow-origin'] !== undefined,
      timestamp: new Date().toISOString()
    }
  });
});

// Add timing middleware for regression testing
app.use('/api/regression-testing', (req, res, next) => {
  req.startTime = Date.now();
  next();
});

// Proxy for Squarespace API
app.use('/api/squarespace', createProxyMiddleware({
  target: 'https://api.squarespace.com',
  changeOrigin: true,
  pathRewrite: { '^/api/squarespace': '' },
}));

// Proxy for Integration Testing API
app.use('/api/integration-testing', createProxyMiddleware({
  target: 'https://postman-integration-testing.glitch.me',
  changeOrigin: true,
  pathRewrite: { '^/api/integration-testing': '' },
}));

// Proxy for Postman Echo API
app.use('/api/echo', createProxyMiddleware({
  target: 'https://postman-echo.com',
  changeOrigin: true,
  pathRewrite: { '^/api/echo': '' },
}));

// Proxy for Mock Data Generation API
app.use('/api/mock-data-generation', createProxyMiddleware({
  target: 'https://mock-data-generation.glitch.me',
  changeOrigin: true,
  pathRewrite: { '^/api/mock-data-generation': '' },
}));

// Proxy for Performance Testing API (fallback to postman-echo.com)
app.use('/api/performance-testing', createProxyMiddleware({
  target: 'https://postman-echo.com',
  changeOrigin: true,
  pathRewrite: { '^/api/performance-testing': '' },
}));

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
  console.log('Swagger UI available at http://localhost:3000/docs');
  console.log('Performance Testing endpoints:');
  console.log('  - Small Query: http://localhost:3000/api/performance-testing/performance/small-query?foo1=bar1&foo2=bar2');
  console.log('  - Large Query: http://localhost:3000/api/performance-testing/performance/large-query?foo1=bar1&foo2=bar2&foo3=bar3...');
  console.log('  - Load Test: http://localhost:3000/api/performance-testing/performance/load-test?paramCount=50&paramSize=100&delay=100');
});
